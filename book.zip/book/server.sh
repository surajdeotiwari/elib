# adding all libraries in requirement.txt
pip freeze > requirement.txt
# This is for opening the file
xdg-open "http://localhost:5000"
# This is for starting the application
python3 app.py

